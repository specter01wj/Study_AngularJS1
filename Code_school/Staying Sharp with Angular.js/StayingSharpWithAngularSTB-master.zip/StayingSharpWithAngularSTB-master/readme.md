#Shaping up with AngularJS Soup to Bits

This repo contains the app built in the soup to bits episode for the Shaping up with AngularJS course.

There is a branch called `starting` that can be used as a starting point for the video. Feel free to clone down this repo and follow along.

#Running the Node App

I used node `0.10.28` at the time of writing the app. We're only using express and lodash, so any version of node (or io.js) should work. You simply need to type: `npm start` in your terminal to start it up.
