Shaping up With Angular.js Example App
==========

May/June 2014 course on Angular.js using Campus.


## Setup

This application is just a collection of static files. Feel free to pull it down and serve it up with whatever backend you would like. It is also available here to [edit in your broswer on plunkr](http://plnkr.co/edit/CmyT5C?p=preview).


